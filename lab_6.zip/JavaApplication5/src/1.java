/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Laiqua Andleeb
 */
public class persistent {
    private int localid,pcode,lang,lat,metro,area;
	private String country, region,city;

public int getlocalId() { return localid; }
public void setlocalId(int id) {
	this.localid = id;
        
}
public int getpcode() { return pcode; }
public void setpcade(int Pid) {
	this.pcode = Pid;
}
public int getlang() { return lang; }
public void setlang(int L) {
	this.lang = L;
}public int getlat() { return lat; }
public void setlat(int La) {
	this.lat= La;
}public int getmetro() { return metro; }
public void setmetro(int M) {
	this.metro = M;
}public int getarea() { return area; }
public void setarea(int A) {
	this.area = A;
}

public String getcountry() { return country; }
public void setcountry(String Country) {
	this.country = Country;
}

public String getregion() { return region; }
public void setregion(String Region) {
	this.region = Region;
}
    public String getcity() { return city; }
public void setcity(String City) {
	this.city = City;
}
}
